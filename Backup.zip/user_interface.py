import logging
from strategy_manager import StrategyManager
from budget_manager import BudgetManager
from performance_manager import PerformanceManager
from backtester import Backtester
from trade_executor import TradeExecutor
from market_monitor import MarketMonitor
from trade_monitor import TradeMonitor

class UserInterface:
    """
    Handles terminal-based interaction for managing trading strategies, budgets, risk levels, and performance metrics.
    """

    def __init__(self, exchange):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.strategy_manager = StrategyManager()
        self.budget_manager = BudgetManager()
        self.performance_manager = PerformanceManager()
        self.backtester = Backtester()
        self.trade_executor = TradeExecutor(exchange, self.budget_manager, self.performance_manager, None)
        self.market_monitor = MarketMonitor(exchange, self.strategy_manager, self.trade_executor)
        self.trade_monitor = TradeMonitor(exchange, self.trade_executor, self.performance_manager)

    def main(self):
        """
        Main loop for the user interface.
        """
        while True:
            print("\n--- Main Menu ---")
            print("1. Create New Strategy")
            print("2. Load Strategy")
            print("3. List Strategies")
            print("4. Assign Budget")
            print("5. View Performance Metrics")
            print("6. Run Backtests")
            print("7. Activate Strategy")
            print("8. Exit")

            choice = input("Enter your choice: ")
            self.handle_menu_choice(choice)

    def handle_menu_choice(self, choice):
        """
        Handles user input for the main menu.
        """
        menu_options = {
            "1": self.create_new_strategy,
            "2": self.load_strategy,
            "3": self.list_strategies,
            "4": self.assign_budget,
            "5": self.view_performance_metrics,
            "6": self.run_backtests,
            "7": self.activate_strategy,
            "8": self.exit_program,
        }

        action = menu_options.get(choice)
        if action:
            action()
        else:
            print("Invalid choice. Please try again.")

    def create_new_strategy(self):
        """
        Prompts the user to create a new strategy, interprets it using the StrategyInterpreter, and saves it.
        """
        try:
            title = input("Enter the strategy title: ")
            description = input("Enter the strategy description: ")

            # Use StrategyInterpreter to interpret the description into a strategy
            from strategy_interpreter import StrategyInterpreter
            interpreter = StrategyInterpreter()
