# main.py

from user_interface import UserInterface

def main():
    ui = UserInterface()
    ui.main()

if __name__ == '__main__':
    main()
