# GenStrat
A plain english to trading strategy generator
